import os
import sys
from quo import clear, echo
from sashay.menu import *



def cli():
    Main.menu()


if __name__ == "__main__":
    cli()
 # try:
#    Main.menu()
 # except KeyboardInterrupt:
 #   clear()
 #   echo(f"Exitting...", reverse=True)
  #  logo.exit()
